DESTINATION_PATH = r"C:\\Users\\Wyatt\\Videos\\Captures"
LEFT_LOGO_PATH = r"C:\Users\Wyatt\Documents\Projects\TVGUI\Images\Larrow.png"
RIGHT_LOGO_PATH = r"C:\Users\Wyatt\Documents\Projects\TVGUI\Images\Rarrow.png"
